import Main from "./Main";
import Login from "./Login";
import Shop from "./Shop";
import Detail from "./Detail";

export {Main, Login, Shop, Detail};