import Header from "./Header";
import Body from "./Body";

export {Header, Body};