import img01 from "./가위.jpg";
import img02 from "./바위.jpg";
import img03 from "./보.jpg";

export {img01, img02, img03};