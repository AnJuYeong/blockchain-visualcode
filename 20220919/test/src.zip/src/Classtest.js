import React, { Component } from 'react'

export default class Classtest extends Component {
  render() {
    return (
      <div></div>
    )
  }
}
