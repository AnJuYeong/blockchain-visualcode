const AppleShop = artifacts.require("AppleShop");

module.exports = function(deployer) {
    deployer.deploy(AppleShop);
}